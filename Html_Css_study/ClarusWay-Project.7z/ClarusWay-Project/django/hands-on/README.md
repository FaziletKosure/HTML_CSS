# Django Hands-on Trainings

List of hands-on trainings within Django workshop as follows;