# Full Stack 6/20 Teamwork Agendas

List of teamwork agendas for Full Stack 6/20  learning path as follows;

- [Teamwork Agenda - 001 : HTML&CSS](./pro-tw-001/tw-001-student.pdf)
