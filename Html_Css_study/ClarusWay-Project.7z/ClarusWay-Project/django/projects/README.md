# Django Projects

List of projects within Django workshop as follows;
