# Javascript Workshop

Javascript Workshop contains hands-on trainings and projects.

- [List of Javascript Hands-on Trainings](./hands-on/README.md)

- [List of Javascript Projects](./projects/README.md)

- [Javascript Session Class-notes](./class-notes/README.md)