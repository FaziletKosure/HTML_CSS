# Django Session Class-notes

